# Boss-Sniffer
A nice tool for bosses to monitor their employees activity
